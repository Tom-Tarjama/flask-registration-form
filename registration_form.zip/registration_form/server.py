from flask import Flask, redirect, render_template, session, flash, request
import re

registration_form= Flask(__name__)
REGEX_EMAIL = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
REGEX_PW = re.compile(r'^(?=.*[A-Z])(?=.*[0-9])')
registration_form.secret_key="Secret"

@registration_form.route('/')
def display():
	return render_template("index.html")

@registration_form.route('/process', methods = ['POST'])
def process():
	first_name = str(request.form['first_name'])
	last_name = str(request.form['last_name'])
	email = request.form['email']
	password = request.form['password']
	password_confirm = request.form['password_confirm']
	errors=0

	#all fields
	if len(first_name) == 0 or len(last_name) == 0 or len(email) == 0 or len(password) == 0 or len(password_confirm) == 0:
		flash("Please fill in all fields")
		errors+=1

	#name fields
	if str.isalpha(first_name) == False or str.isalpha(last_name) == False:
		flash("Name fields may only contain alphabetic characters")
		errors+=1

	#email fields
	if REGEX_EMAIL.match(email) ==None:
		flash("Invalid email")
		errors+=1

	#password fields
	if len(password) <= 8:
		flash("Password must be at least 9 characters long")
		errors+=1
	if password != password_confirm:
		flash("Passwords do not match")
		errors+=1
	if REGEX_PW.match(password) ==None:
		flash("Your password must contain at least one uppercase letter and one number")
		errors+=1

	#success
	if errors==0:
		flash("Registration complete. Thank you!")

	return redirect('/')


registration_form.run(debug=True)